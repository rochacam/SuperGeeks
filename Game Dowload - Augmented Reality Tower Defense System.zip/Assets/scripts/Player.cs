﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

	public float velocidade;
	public float alturaPulo;

	// Use this for initialization
	void Start() {
		
		
	}
	
	// Update is called once per frame
	void Update (){ 
			if(Input.GetAxis ("Horizontal") > 0) {
				transform.Translate (Vector2.right * velocidade * Time.deltaTime);
				transform.localScale = new Vector3 (1, 1, 1);
			}
		if (Input.GetAxis ("Horizontal") < 0) {
			transform.Translate (Vector2.left * velocidade * Time.deltaTime);
			transform.localScale = new Vector3 (-1, 1, 1);
		}
			if(Input.GetAxis ("Vertical") > 0) {
				transform.Translate (Vector2.up * alturaPulo * Time.deltaTime);
				transform.localScale = new Vector3 (1, 1, 0);
			}

	   }
	}

